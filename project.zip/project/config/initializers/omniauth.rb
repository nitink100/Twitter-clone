# Rails.application.config.middleware.use OmniAuth::Builder do
#     provider :developer if Rails.env.development?
#     provider(
#         :twitter2,
#         grant_type: 'authorization_code',
#         api_secret: " GFGFQ4ZKUBtX5QPK5pCc1wlnqS8UhgmqgihT8yge1vgpF6ADQ9",
#         client_id: "MHNRb3oyRDVhdWR3dGNJRm5VNnI6MTpjaQ",
#         client_secret: "kIffbMt_j6UIzcJvYXkHmlaCYc-yJ3zEQm45rOAbsS-FXTie_",
#         callback_path: '/auth/twitter2/callback',
#         scope: 'tweet.read users.read'
#     )
#   end
  