Rails.application.routes.draw do
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
  root 'sessions#new'
  post '/authorize', to: 'sessions#create'
  get '/authorize', to: 'sessions#authorize'
  #post '/authorize', to: 'sessions#create'
  get '/sessions/authorize', to: 'sessions#authorize'
  post '/auth/twitter2/callback', to: 'sessions#authorize'
  get '/auth/twitter2/callback', to: 'sessions#authorize'
end
