class SessionsController < ApplicationController
    require 'rest-client'
    require 'cgi'
    #before_action :token_place
    skip_before_action :verify_authenticity_token
    # def new
    #     render new
    #     #redirect_to :controller=>"sessions", :action=>"authorize"
    # end
    
    def new
        render 'new'
    end

    def create
        #response = RestClient.get "twitter.com/i/oauth2/authorize",{params:{response_type: "code", client_id: "MHNRb3oyRDVhdWR3dGNJRm5VNnI6MTpjaQ", redirect_uri: "http://127.0.0.1:3000/auth/twitter2/callback", scope: "tweet.read users.read follows.read follows.write", state: "state", code_challenge: "challenge", code_challenge_method: "plain"}}
        #byebug
        enc_key = CGI.escape "0v3aiDNdD7QXo2K5AyBoYyt9Q"
        enc_secret = CGI.escape("GFGFQ4ZKUBtX5QPK5pCc1wlnqS8UhgmqgihT8yge1vgpF6ADQ9")
        enc = enc_key+":"+enc_secret
        #render json: enc
        #bearer_token = "AAAAAAAAAAAAAAAAAAAAAFXLkAEAAAAAaGA4dcvt9rDh8IW%2FtUnPFu7tcLc%3DNHr0F4AcjjlQTB17eF1X7A1BIC5sJGLqFZIVLyxgDWNCSfJv5c"
        enc_bearer = Base64.encode64(enc)
            #:client_id=>"MHNRb3oyRDVhdWR3dGNJRm5VNnI6MTpjaQ", :client_secret=>"-kIffbMt_j6UIzcJvYXkHmlaCYc-yJ3zEQm45rOAbsS-FXTie_"}
        #byebug
        response = RestClient.post("https://api.twitter.com/oauth/request_token",{:grant_type=>{:client_id=>"MHNRb3oyRDVhdWR3dGNJRm5VNnI6MTpjaQ", :client_secret=>"-kIffbMt_j6UIzcJvYXkHmlaCYc-yJ3zEQm45rOAbsS-FXTie_"}},{:Authorization=>"Basic #{enc}", :Content-Type=>"application/x-www-form-urlencoded;charset=UTF-8"})
        #https://twitter.com/i/oauth2/authorize?response_type=code&client_id=M1M5R3BMVy13QmpScXkzTUt5OE46MTpjaQ&redirect_uri=https://www.example.com&scope=tweet.read%20users.read%20account.follows.read%20account.follows.write&state=state&code_challenge=challenge&code_challenge_method=plain
        # response  = Restclient.post("https://api.twitter.com/oauth/request_token")
        #user_info = request.env['omniauth.auth']
        #redirect_to "/sessions/authorize"
        render json: response

    end

    def authorize
        render json: "success"
    end

    #private 

    # def token_place 
    #     request.headers["Authorization"] = "Bearer AAAAAAAAAAAAAAAAAAAAAFXLkAEAAAAAaGA4dcvt9rDh8IW%2FtUnPFu7tcLc%3DNHr0F4AcjjlQTB17eF1X7A1BIC5sJGLqFZIVLyxgDWNCSfJv5c"
    # end
end
