class User < ApplicationRecord

end

